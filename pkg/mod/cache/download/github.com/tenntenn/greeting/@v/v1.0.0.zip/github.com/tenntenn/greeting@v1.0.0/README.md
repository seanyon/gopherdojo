# greeting

greeting pacakge is used for sample codes.
