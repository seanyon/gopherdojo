package greeting

// Do関数は挨拶文を返します.
func Do() string {
	return "こんにちは"
}
